import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [users, setUsers] = useState([]);

  const loadUsers = async () => {
    const response = await fetch("https://reqres.in/api/users?page=1");
    const jsonres = await response.json();
    setUsers(jsonres.data);
  }

  return (
    <div className='App'>
      <header className="header">
        <h1 className="title">Welcome to Geek's World!</h1>
        <button className="get-data-button" onClick={loadUsers}>Get Data</button>
      </header>

      <main className="main">
        <h2 className="users-title">Users:</h2>
        <ul className="user-list">
          {users.map(({ id, first_name, last_name, email, avatar }) => (
            <li key={id}>
              <div className="user">
                <img src={avatar} alt="User Avatar" className="avatar" />
                <div className="user-details">
                  <h3 className="user-name">{first_name} {last_name}</h3>
                  <p className="user-email">{email}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </main>
    </div>
  )
}

export default App;